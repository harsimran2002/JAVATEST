package com.company;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class Showroomt {

    @Test
    void addToInventory() {
        String [] b= {"Bugati", "Ninja"};
        Showroom s = new Showroom("Bugati", List.of(b));
        s.setName("Dodge");
        assertEquals("Dodge",s.getName());
    }
}