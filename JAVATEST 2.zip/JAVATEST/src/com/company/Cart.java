package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Cart {

    @Test
    void currentCarPrice() {
        Car c = new Car("32A23",5000,"Dodge",2017,2022,15,4);
        c.setNumOfPassengers(5);
        assertEquals(5,c.getNumOfPassengers());
    }
}